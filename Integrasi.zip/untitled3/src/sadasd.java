public class sadasd {
    // Fungsi f(x) = 4 / (1 + x^2)
    public static double f(double x) {
        return 4 / (1 + x * x);
    }

    // Metode untuk menghitung integral menggunakan metode Riemann
    public static double riemannIntegral(double a, double b, int n) {
        double deltaX = (b - a) / n;
        double total = 0.0;
        for (int i = 0; i < n; i++) {
            double x_i = a + (i + 0.5) * deltaX;
            total += f(x_i) * deltaX;
        }
        return total;
    }

    // Metode untuk menghitung galat RMS
    public static double calculateRMSError(double estimate, double reference) {
        return Math.sqrt(Math.pow(estimate - reference, 2));
    }

    public static void main(String[] args) {
        // Nilai referensi pi
        double piReference = 3.14159265358979323846;

        // Variasi N yang akan digunakan untuk pengujian
        int[] nValues = {10, 100, 1000, 10000};

        // Header output
        System.out.printf("%-10s %-20s %-20s %-20s%n", "N", "Estimate Pi", "Execution Time (ms)", "RMS Error");

        for (int n : nValues) {
            long startTime = System.nanoTime();

            // Hitung nilai integral menggunakan metode Riemann
            double piEstimate = riemannIntegral(0.0, 1.0, n);

            long endTime = System.nanoTime();
            long executionTime = (endTime - startTime) / 1000000; // dalam milidetik

            // Hitung galat RMS
            double rmsError = calculateRMSError(piEstimate, piReference);

            // Output hasil
            System.out.printf("%-10d %-20.15f %-20d %-20.15f%n", n, piEstimate, executionTime, rmsError);

            // Verifikasi bahwa galat RMS berada dalam batas toleransi
            double tolerance = 1e-5;
            if (rmsError > tolerance) {
                System.out.println("Galat RMS terlalu tinggi untuk N = " + n);
            }
        }
    }
}
