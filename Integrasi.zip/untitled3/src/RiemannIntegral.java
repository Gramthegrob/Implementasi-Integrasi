public class RiemannIntegral {

    // Fungsi f(x) = 4 / (1 + x^2)
    public static double f(double x) {
        return 4 / (1 + x * x);
    }

    // Metode untuk menghitung integral menggunakan metode Riemann
    public static double riemannIntegral(double a, double b, int n) {
        // Lebar setiap subinterval
        double deltaX = (b - a) / n;

        // Inisialisasi jumlah Riemann
        double total = 0.0;

        // Hitung jumlah Riemann
        for (int i = 0; i < n; i++) {
            // Titik tengah subinterval ke-i
            double x_i = a + (i + 0.5) * deltaX;
            // Tambahkan kontribusi subinterval ke jumlah total
            total += f(x_i) * deltaX;
        }

        return total;
    }

    // Metode untuk menghitung galat RMS
    public static double calculateRMSError(double estimate, double reference) {
        return Math.sqrt(Math.pow(estimate - reference, 2));
    }

    public static void main(String[] args) {
        // Interval integrasi dari 0 sampai 1
        double a = 0.0;
        double b = 1.0;

        // Nilai referensi pi
        double piReference = 3.14159265358979323846;

        // Variasi N yang akan digunakan
        int[] nValues = {100, 1000, 10000, 100000};

        // Header output
        System.out.printf("%-10s %-20s %-20s%n", "N", "Estimate Pi", "Execution Time (ms)", "RMS Error");

        for (int n : nValues) {
            // Mulai pengukuran waktu
            long startTime = System.nanoTime();

            // Hitung nilai integral menggunakan metode Riemann
            double piEstimate = riemannIntegral(a, b, n);

            // Akhiri pengukuran waktu
            long endTime = System.nanoTime();
            long executionTime = (endTime - startTime) / 1000000; // dalam milidetik

            // Hitung galat RMS
            double rmsError = calculateRMSError(piEstimate, piReference);

            // Output hasil
            System.out.printf("%-10d %-20.15f %-20d %-20.15f%n", n, piEstimate, executionTime, rmsError);
        }
    }
}
